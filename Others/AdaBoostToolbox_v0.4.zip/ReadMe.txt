See Manual.pdf for description of toolbox and examples.
You can run TestCompare.m or Example.m to see toolbox in work.
Also see License.txt before using.
Thanks for downloading GML AdaBoost Matlab Toolbox!